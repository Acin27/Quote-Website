﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using Website.Data;
using Website.Models;

namespace Website.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HomeController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult AddPost()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddPost(Post post)
        {
            try
            {
                var image = new Image();
                IFormFile file = Request.Form.Files.FirstOrDefault()!;
                using (var dataStream = new MemoryStream())
                {
                    file.CopyTo(dataStream);
                    image.ImageData = dataStream.ToArray();
                }
                _context.Images.Add(image);
                _context.SaveChanges();

                var realPost = new Post
                {
                    LikesCount = 0,
                    CreatedDate = DateTime.Now,
                    CreatedBy = User.Identity?.Name!,
                    ImageId = image.Id,
                };
                _context.Posts.Add(realPost);
                _context.SaveChanges();
                if (User.IsInRole("Admin"))
                {
                    return RedirectToAction("Posts");
                }
                else
                {
                    return RedirectToAction("PostsforUser");
                }
            }
            catch (Exception ex)
            {
                return View(ex.Message);
            }
        }

        [Authorize(Roles ="Admin")]
        public IActionResult Posts()
        {
            var posts = _context.Posts.Include(a => a.Image).ToList();
            return View(posts);
        }

        [Authorize(Roles = "Admin, User")]
        public IActionResult PostsforUser()
        {
            var posts = _context.Posts.Include(a => a.Image).ToList();
            return View(posts);
        }

        [HttpPost]
        public int LikePost(int postid)
        {
            if (LikeCheck(postid)) 
            {
                var like = new Likes
                {
                    PostId = postid,
                    UserId = User.Identity?.Name!
                };
                _context.PostLikes.Add(like);
                _context.SaveChanges();
                var post = _context.Posts.Find(postid)!;
                post.LikesCount = _context.PostLikes.Where(a => a.PostId == postid).Count();
                _context.Update(post);
                _context.SaveChanges();
                return post.LikesCount;
            }
            else
            {
                var like = _context.PostLikes.Where(a => a.PostId == postid &&
                                                    a.UserId == User.Identity!.Name).FirstOrDefault()!;
                _context.PostLikes.Remove(like);
                _context.SaveChanges();
                var post = _context.Posts.Find(postid)!;
                post.LikesCount = _context.PostLikes.Where(a => a.PostId == postid).Count();
                _context.Update(post);
                _context.SaveChanges();
                return post.LikesCount;
            }
        }

        public bool LikeCheck(int postid)
        {
            var post = _context.Posts.Find(postid)!;
            var like = _context.PostLikes.Where(a => a.PostId == postid &&
                                                a.UserId == User.Identity!.Name).FirstOrDefault();
            if (like == null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        [HttpPost]
        public IActionResult DeletePost(int id)
        {
            try
            {
                var post = _context.Posts.Find(id)!;
                //remove post likes
                var postlikes = _context.PostLikes.Where(a => a.PostId == id).ToList();
                _context.PostLikes.RemoveRange(postlikes);
                _context.SaveChanges();
                //remove post
                _context.Posts.Remove(post);
                _context.SaveChanges();
                return RedirectToAction("Posts");
            }
            catch (Exception ex)
            {
                return View(ex.Message);
            }
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}