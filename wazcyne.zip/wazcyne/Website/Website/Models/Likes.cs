﻿using System.ComponentModel.DataAnnotations;

namespace Website.Models
{
    public class Likes
    {
        [Key]
        public int Id { get; set; }
        public string UserId { get; set; } = string.Empty;
        public int PostId { get; set; }
    }
}
