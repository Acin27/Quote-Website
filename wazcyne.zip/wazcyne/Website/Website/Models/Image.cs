﻿using System.ComponentModel.DataAnnotations;

namespace Website.Models
{
    public class Image
    {
        [Key]
        public int Id { get; set; }
        public byte[] ImageData { get; set; } = new byte[0];
    }
}
