﻿
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Website.Models
{
    public class PostInterface : Post
    {
        [Required]
        [Display(Name ="Image")]
        public byte[] ImageData { get; set; } = new byte[0];
    }
}
