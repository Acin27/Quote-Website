﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Website.Models
{
    public class Post
    {
        [Key]
        public int Id { get; set; }
        [Display(Name = "Likes")]
        public int LikesCount { get; set; }
        [Display(Name ="Created Date")]
        public DateTime CreatedDate { get; set; }
        [Display(Name ="Posted By")]
        public string CreatedBy { get; set; } = string.Empty;

        [ForeignKey("Image")]
        public int ImageId { get; set; }
        public Image? Image { get; set; }
    }
}
